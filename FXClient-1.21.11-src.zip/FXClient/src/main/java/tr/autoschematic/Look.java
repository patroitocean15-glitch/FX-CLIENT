package tr.autoschematic;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.MathHelper;
import tr.autoschematic.core.Features;

/** FreeLook durumu: kamera, oyuncunun gerçek bakış yönünden bağımsız döner. */
public final class Look {
    private Look() {
    }

    public static boolean active;
    public static float yaw;
    public static float pitch;
    private static boolean was;

    public static void tick(MinecraftClient mc) {
        boolean want = mc.player != null && Features.FREE_LOOK != null && Features.FREE_LOOK.enabled;
        if (want && !was) {
            yaw = mc.player.getYaw();
            pitch = mc.player.getPitch();
        }
        was = want;
        active = want;
    }

    /** Fare hareketi: vanilla ile aynı hassasiyet (0.15). */
    public static void onMouse(double dx, double dy) {
        yaw += (float) dx * 0.15f;
        pitch = MathHelper.clamp(pitch + (float) dy * 0.15f, -90f, 90f);
    }
}
