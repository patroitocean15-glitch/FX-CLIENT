package tr.autoschematic.gui;

import tr.autoschematic.core.Features;

/** FX Client gri teması. Vurgu rengi, opaklık ve köşe yuvarlaklığı "GUI" modülünden gelir. */
public final class Theme {
    private Theme() {
    }

    public static int accent() {
        return Features.GUI.accent.argb();
    }

    public static int accentA(int alpha) {
        return Features.GUI.accent.argb(alpha);
    }

    public static int bg() {
        return (Features.GUI.opacity.i() << 24) | 0x0F1012;
    }

    public static int panel() {
        return (Math.min(255, Features.GUI.opacity.i() + 6) << 24) | 0x17181B;
    }

    public static int row() {
        return 0xFF1E1F23;
    }

    public static int rowHover() {
        return 0xFF292B30;
    }

    public static int off() {
        return 0xFF3B3D44;
    }

    public static int text() {
        return 0xFFE8E9EC;
    }

    public static int sub() {
        return 0xFF8E9199;
    }

    public static int radius() {
        return Features.GUI.radius.i();
    }
}
