package tr.autoschematic.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;
import tr.autoschematic.Look;
import tr.autoschematic.core.Features;

/** Basit perspektif kamera: dünya noktalarını ekran koordinatına çevirir (HUD üzerine işaret çizmek için). */
public final class WorldCam {
    private final Vec3d eye;
    private final double[] f = new double[3];
    private final double[] r = new double[3];
    private final double[] u = new double[3];
    private final double tx;
    private final double ty;
    public final int sw;
    public final int sh;

    public WorldCam(Vec3d eye, float yawDeg, float pitchDeg, double fovDeg, int sw, int sh) {
        this.eye = eye;
        this.sw = sw;
        this.sh = sh;
        double yaw = Math.toRadians(yawDeg);
        double pitch = Math.toRadians(pitchDeg);
        f[0] = -Math.sin(yaw) * Math.cos(pitch);
        f[1] = -Math.sin(pitch);
        f[2] = Math.cos(yaw) * Math.cos(pitch);
        r[0] = -Math.cos(yaw);
        r[1] = 0;
        r[2] = -Math.sin(yaw);
        u[0] = r[1] * f[2] - r[2] * f[1];
        u[1] = r[2] * f[0] - r[0] * f[2];
        u[2] = r[0] * f[1] - r[1] * f[0];
        this.ty = Math.tan(Math.toRadians(fovDeg) / 2.0);
        this.tx = ty * ((double) sw / (double) sh);
    }

    /** Oyuncunun şu anki bakışı, FreeLook/Zoom/Custom FOV dahil. */
    public static WorldCam current(MinecraftClient mc, float tickProgress) {
        ClientPlayerEntity p = mc.player;
        float yaw = Look.active ? Look.yaw : p.getYaw(tickProgress);
        float pitch = Look.active ? Look.pitch : p.getPitch(tickProgress);
        double fov;
        if (Features.ZOOM.enabled) fov = Features.ZOOM.fov.v;
        else if (Features.CUSTOM_FOV.enabled) fov = Features.CUSTOM_FOV.fov.v;
        else fov = mc.options.getFov().getValue();
        return new WorldCam(p.getEyePos(), yaw, pitch, fov,
                mc.getWindow().getScaledWidth(), mc.getWindow().getScaledHeight());
    }

    /** Kamera uzayı: {sağ, yukarı, ileri}. */
    private double[] toCam(double x, double y, double z) {
        double dx = x - eye.x;
        double dy = y - eye.y;
        double dz = z - eye.z;
        return new double[]{
                dx * r[0] + dy * r[1] + dz * r[2],
                dx * u[0] + dy * u[1] + dz * u[2],
                dx * f[0] + dy * f[1] + dz * f[2]};
    }

    private double[] screen(double[] c) {
        return new double[]{
                (c[0] / (c[2] * tx) * 0.5 + 0.5) * sw,
                (0.5 - c[1] / (c[2] * ty) * 0.5) * sh};
    }

    /** Noktanın ekran konumu {x, y}; kameranın arkasındaysa null. */
    public double[] project(double x, double y, double z) {
        double[] c = toCam(x, y, z);
        if (c[2] < 0.1) return null;
        return screen(c);
    }

    /** İki dünya noktası arasında çizgi çizer (yakın düzlemde kırpar). */
    public void line(DrawContext ctx, double ax, double ay, double az, double bx, double by, double bz,
                     int col, int th) {
        double[] a = toCam(ax, ay, az);
        double[] b = toCam(bx, by, bz);
        double near = 0.1;
        if (a[2] < near && b[2] < near) return;
        if (a[2] < near) a = clip(a, b, near);
        else if (b[2] < near) b = clip(b, a, near);
        double[] sa = screen(a);
        double[] sb = screen(b);
        Draw.line(ctx, sa[0], sa[1], sb[0], sb[1], sw, sh, col, th);
    }

    private static double[] clip(double[] behind, double[] front, double near) {
        double t = (near - behind[2]) / (front[2] - behind[2]);
        return new double[]{
                behind[0] + (front[0] - behind[0]) * t,
                behind[1] + (front[1] - behind[1]) * t,
                near};
    }
}
