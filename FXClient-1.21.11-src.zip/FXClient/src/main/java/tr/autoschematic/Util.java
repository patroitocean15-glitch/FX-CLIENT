package tr.autoschematic;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public final class Util {
    private Util() {
    }

    /** Ekranın altındaki action bar'a kısa bilgi yazar. */
    public static void info(MinecraftClient mc, String msg) {
        if (mc != null && mc.player != null) {
            mc.player.sendMessage(Text.literal("[FX] " + msg).formatted(Formatting.AQUA), true);
        }
    }

    /** Sohbet penceresine (sadece sana görünen) satır yazar. */
    public static void chat(MinecraftClient mc, Text t) {
        if (mc != null && mc.player != null) {
            mc.player.sendMessage(t, false);
        }
    }

    /**
     * GameProfile 1.21.9'dan beri record (name()), eskiden getName() idi.
     * Reflection ile ikisini de deniyoruz, böylece sürüm farkı derlemeyi bozmaz.
     */
    public static String profileName(Object profile) {
        if (profile == null) return "?";
        for (String m : new String[]{"name", "getName"}) {
            try {
                Object r = profile.getClass().getMethod(m).invoke(profile);
                if (r instanceof String s) return s;
            } catch (Throwable ignored) {
                // sıradaki ismi dene
            }
        }
        return "?";
    }

    /** Oyuncu envanter indeksi (0-8 hotbar, 9-35 ana envanter) -> PlayerScreenHandler slot id. */
    public static int screenSlot(int invIndex) {
        return invIndex < 9 ? 36 + invIndex : invIndex;
    }

    /** [from, to) aralığındaki envanter indekslerinde eşyayı arar; yoksa -1. */
    public static int findItem(PlayerEntity p, Item item, int from, int to) {
        PlayerInventory inv = p.getInventory();
        for (int i = from; i < to; i++) {
            if (inv.getStack(i).isOf(item)) return i;
        }
        return -1;
    }
}
