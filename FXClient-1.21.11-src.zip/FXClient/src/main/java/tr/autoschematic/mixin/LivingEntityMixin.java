package tr.autoschematic.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import tr.autoschematic.modules.visual.SlowHand;

/** Slow Hand: yerel oyuncunun el sallama ilerlemesini (birinci ve üçüncü şahıs) değiştirir. */
@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    @Inject(method = "getHandSwingProgress", at = @At("RETURN"), cancellable = true, require = 0)
    private void autoschematic$swing(float tickProgress, CallbackInfoReturnable<Float> cir) {
        if ((Object) this == MinecraftClient.getInstance().player) {
            Float v = SlowHand.modify(cir.getReturnValue(), tickProgress);
            if (v != null) cir.setReturnValue(v);
        }
    }
}
