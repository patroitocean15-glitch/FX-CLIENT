package tr.autoschematic.mixin;

import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import tr.autoschematic.Look;

/** FreeLook açıkken kamera, oyuncunun yönü yerine kendi yaw/pitch değerini kullanır. */
@Mixin(Camera.class)
public abstract class CameraMixin {
    @ModifyArg(method = "update",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V", ordinal = 0),
            index = 0, require = 0)
    private float autoschematic$yaw(float original) {
        return Look.active ? Look.yaw : original;
    }

    @ModifyArg(method = "update",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V", ordinal = 0),
            index = 1, require = 0)
    private float autoschematic$pitch(float original) {
        return Look.active ? Look.pitch : original;
    }
}
