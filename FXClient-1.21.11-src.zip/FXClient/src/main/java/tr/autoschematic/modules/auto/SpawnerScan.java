package tr.autoschematic.modules.auto;

import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Spawner modüllerinin ortak tarayıcısı: yüklü chunk'lardaki spawner'ları ve türlerini saniyede bir günceller. */
public final class SpawnerScan {
    private SpawnerScan() {
    }

    public static final class Spawner {
        public final BlockPos pos;
        public final String type;

        Spawner(BlockPos pos, String type) {
            this.pos = pos;
            this.type = type;
        }
    }

    public static final List<Spawner> list = new ArrayList<>();
    private static final Map<Long, String> TYPES = new HashMap<>();
    private static long lastScan = Long.MIN_VALUE;

    private static final Pattern SPAWN_DATA =
            Pattern.compile("SpawnData:\\s*\\{\\s*entity:\\s*\\{\\s*id:\\s*[\"']([^\"']+)[\"']");
    private static final Pattern ANY_ID = Pattern.compile("id:\\s*[\"']([^\"']+)[\"']");

    public static void tick(MinecraftClient mc, int chunkRadius) {
        ClientWorld w = mc.world;
        ClientPlayerEntity p = mc.player;
        if (w == null || p == null) {
            list.clear();
            TYPES.clear();
            lastScan = Long.MIN_VALUE;
            return;
        }
        long now = w.getTime();
        if (now >= lastScan && now - lastScan < 20) return;     // saniyede bir
        lastScan = now;

        int pcx = p.getBlockX() >> 4;
        int pcz = p.getBlockZ() >> 4;
        int r = Math.min(chunkRadius, mc.options.getViewDistance().getValue());
        List<BlockPos> found = new ArrayList<>();
        for (int cx = pcx - r; cx <= pcx + r; cx++) {
            for (int cz = pcz - r; cz <= pcz + r; cz++) {
                Chunk ch = w.getChunk(cx, cz, ChunkStatus.FULL, false);
                if (ch == null) continue;
                for (BlockPos bp : ch.getBlockEntityPositions()) {
                    if (w.getBlockState(bp).isOf(Blocks.SPAWNER)) found.add(bp.toImmutable());
                }
            }
        }
        BlockPos me = p.getBlockPos();
        found.sort(Comparator.comparingDouble((BlockPos b) -> b.getSquaredDistance(me)));

        list.clear();
        for (BlockPos bp : found) {
            long key = bp.asLong();
            String t = TYPES.get(key);
            if (t == null || t.equals("?")) {
                t = resolveType(w, bp);
                TYPES.put(key, t);
            }
            list.add(new Spawner(bp, t));
        }
    }

    /** Spawner'ın içindeki mob türünü bloğun senkronize NBT verisinden okur. */
    private static String resolveType(ClientWorld w, BlockPos bp) {
        try {
            BlockEntity be = w.getBlockEntity(bp);
            if (be == null) return "?";
            String snbt = be.createNbt(w.getRegistryManager()).toString();
            Matcher m = SPAWN_DATA.matcher(snbt);
            if (m.find()) return pretty(m.group(1));
            m = ANY_ID.matcher(snbt);
            if (m.find()) return pretty(m.group(1));
        } catch (Throwable ignored) {
            // tür okunamadı
        }
        return "?";
    }

    private static String pretty(String id) {
        int c = id.indexOf(':');
        String name = (c >= 0 ? id.substring(c + 1) : id).replace('_', ' ');
        StringBuilder sb = new StringBuilder();
        for (String part : name.split(" ")) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(part.substring(0, 1).toUpperCase(Locale.ROOT)).append(part.substring(1));
        }
        return sb.length() == 0 ? "?" : sb.toString();
    }
}
