package tr.autoschematic.modules.auto;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import tr.autoschematic.Util;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;

import java.util.List;

/** Madencilik/mob çöplerini (taş, toprak, çürük et...) envanter dolarken yere atar. Hotbar'a dokunmaz. */
public final class AutoDrop extends Feature {
    private static final List<String> BLOCK_JUNK = List.of(
            "cobblestone", "cobbled_deepslate", "dirt", "gravel", "andesite", "diorite", "granite", "tuff",
            "netherrack", "deepslate");
    private static final List<String> MOB_JUNK = List.of(
            "rotten_flesh", "spider_eye", "poisonous_potato", "bone");

    private final Setting.Bool blocks = add(new Setting.Bool("Taş/toprak çöpleri", true));
    private final Setting.Bool mobs = add(new Setting.Bool("Mob çöpleri", true));
    private final Setting.Bool onlyFull = add(new Setting.Bool("Sadece envanter dolarken", true));
    private final Setting.Num delay = add(new Setting.Num("Gecikme (tick)", 6, 2, 40, 1));
    private int wait;

    public AutoDrop() {
        super("Auto Drop", "Envanter dolarken çöp eşyaları (taş, toprak, çürük et...) atar. Hotbar'a dokunmaz.",
                Category.AUTO);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientPlayerInteractionManager im = mc.interactionManager;
        if (p == null || im == null) return;
        if (p.currentScreenHandler != p.playerScreenHandler) return;
        if (!p.playerScreenHandler.getCursorStack().isEmpty()) return;
        if (wait > 0) {
            wait--;
            return;
        }
        PlayerInventory inv = p.getInventory();
        if (onlyFull.v) {
            int free = 0;
            for (int i = 0; i < 36; i++) {
                if (inv.getStack(i).isEmpty()) free++;
            }
            if (free > 2) return;
        }
        for (int i = 9; i < 36; i++) {
            ItemStack s = inv.getStack(i);
            if (s.isEmpty()) continue;
            String id = Registries.ITEM.getId(s.getItem()).getPath();
            if ((blocks.v && BLOCK_JUNK.contains(id)) || (mobs.v && MOB_JUNK.contains(id))) {
                im.clickSlot(p.playerScreenHandler.syncId, Util.screenSlot(i), 1, SlotActionType.THROW, p);
                wait = delay.i();
                return;
            }
        }
    }
}
