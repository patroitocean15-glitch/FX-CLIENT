package tr.autoschematic.modules.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;

/** İstemci tarafı gece görüşü: karanlıkta her yer aydınlık görünür (sunucuya bir şey göndermez). */
public final class Fullbright extends Feature {
    public Fullbright() {
        super("Fullbright", "Karanlıkta bile her yeri aydınlık gösterir (sadece senin ekranında).", Category.VISUALS);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        StatusEffectInstance cur = p.getStatusEffect(StatusEffects.NIGHT_VISION);
        if (cur == null || cur.getDuration() < 400) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1200, 0, false, false));
        }
    }

    @Override
    public void onDisable() {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p != null) p.removeStatusEffect(StatusEffects.NIGHT_VISION);
    }
}
