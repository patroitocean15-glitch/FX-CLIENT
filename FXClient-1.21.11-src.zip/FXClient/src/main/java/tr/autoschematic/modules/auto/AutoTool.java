package tr.autoschematic.modules.auto;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.util.hit.BlockHitResult;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;

/** Bir bloğa vururken (sol tık basılı) hotbar'daki en hızlı aleti otomatik seçer. */
public final class AutoTool extends Feature {
    private final Setting.Bool restore = add(new Setting.Bool("Bırakınca eski slota dön", true));
    private int prev = -1;

    public AutoTool() {
        super("Auto Tool", "Bloğa vururken hotbar'daki en uygun aleti otomatik seçer.", Category.AUTO);
    }

    @Override
    public void onDisable() {
        prev = -1;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null) {
            prev = -1;
            return;
        }
        PlayerInventory inv = p.getInventory();
        if (!mc.options.attackKey.isPressed()) {
            if (prev >= 0 && restore.v) inv.setSelectedSlot(prev);
            prev = -1;
            return;
        }
        if (!(mc.crosshairTarget instanceof BlockHitResult hit)) return;
        BlockState st = mc.world.getBlockState(hit.getBlockPos());
        if (st.isAir()) return;

        int best = -1;
        float bestSpeed = 1.0f;
        for (int i = 0; i < 9; i++) {
            float sp = inv.getStack(i).getMiningSpeedMultiplier(st);
            if (sp > bestSpeed) {
                bestSpeed = sp;
                best = i;
            }
        }
        if (best >= 0 && best != inv.getSelectedSlot()) {
            if (prev < 0) prev = inv.getSelectedSlot();
            inv.setSelectedSlot(best);
        }
    }
}
