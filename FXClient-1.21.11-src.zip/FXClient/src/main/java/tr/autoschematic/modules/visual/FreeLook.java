package tr.autoschematic.modules.visual;

import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;

/** Kamera, oyuncunun bakış yönünden bağımsız döner. İpucu: tuşu "Basılı tut" moduna al. */
public final class FreeLook extends Feature {
    public FreeLook() {
        super("Free Look", "Fareyle kamerayı çevirirken oyuncunun yönü değişmez. Tuşu 'Basılı tut' yapabilirsin.",
                Category.VISUALS);
    }
}
