package tr.autoschematic.modules.auto;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import tr.autoschematic.Util;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;

/** Oltayı otomatik atar; şamandıra batınca (balık vurunca) çeker ve yeniden atar. */
public final class AutoFish extends Feature {
    private final Setting.Num recast = add(new Setting.Num("Yeniden atma beklemesi (tick)", 25, 10, 100, 5));
    private final Setting.Num sens = add(new Setting.Num("Vurma hassasiyeti", 4, 1, 10, 1));
    private int wait;
    private int sinceCast;

    public AutoFish() {
        super("Auto Fish", "Oltayı otomatik atar, balık vurunca çeker ve tekrar atar. Oltayı hotbar'da tut.",
                Category.AUTO);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientPlayerInteractionManager im = mc.interactionManager;
        if (p == null || im == null || mc.currentScreen != null) return;

        if (!p.getMainHandStack().isOf(Items.FISHING_ROD)) {
            int s = Util.findItem(p, Items.FISHING_ROD, 0, 9);
            if (s >= 0) p.getInventory().setSelectedSlot(s);
            return;
        }
        if (wait > 0) {
            wait--;
            return;
        }

        FishingBobberEntity hook = p.fishHook;
        if (hook == null) {                       // olta suda değil: at
            im.interactItem(p, Hand.MAIN_HAND);
            p.swingHand(Hand.MAIN_HAND);
            sinceCast = 0;
            wait = 12;
            return;
        }

        sinceCast++;
        boolean bite = sinceCast > 30 && hook.isTouchingWater() && hook.getVelocity().y < -(0.01 * sens.v);
        if (bite || sinceCast > 1800) {           // vurdu (ya da çok bekledi): çek
            im.interactItem(p, Hand.MAIN_HAND);
            p.swingHand(Hand.MAIN_HAND);
            wait = recast.i();
            sinceCast = 0;
        }
    }
}
