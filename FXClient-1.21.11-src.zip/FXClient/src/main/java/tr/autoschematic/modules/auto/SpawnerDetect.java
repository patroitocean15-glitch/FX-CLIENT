package tr.autoschematic.modules.auto;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;
import tr.autoschematic.gui.Draw;
import tr.autoschematic.gui.Hud;
import tr.autoschematic.gui.WorldCam;

import java.util.List;

/**
 * Yüklü chunk'lardaki tüm mob spawner'ları kırmızı çubuk, chunk çerçevesi ve etiketle işaretler.
 * İşaretler ekran uzayında çizilir (duvarların arkasından da görünür).
 * Sesli/sohbetli uyarı için "Auto Spawner Notifier" modülünü aç.
 */
public final class SpawnerDetect extends Feature {
    private final Setting.Num chunks = add(new Setting.Num("Tarama yarıçapı (chunk)", 12, 2, 32, 1));
    private final Setting.Bool beam = add(new Setting.Bool("Kırmızı çubuk", true));
    private final Setting.Bool chunkBox = add(new Setting.Bool("Chunk çerçevesi", true));
    private final Setting.Bool list = add(new Setting.Bool("Liste göster", true));
    private final Setting.Color color = add(new Setting.Color("İşaret rengi", 0xFF3B30));

    public SpawnerDetect() {
        super("Auto Spawner Detect",
                "Yüklü chunk'lardaki tüm spawner'ları kırmızı çubuk + chunk çerçevesiyle işaretler.",
                Category.AUTO);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        SpawnerScan.tick(mc, chunks.i());
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc, float tickProgress) {
        ClientPlayerEntity p = mc.player;
        List<SpawnerScan.Spawner> found = SpawnerScan.list;
        if (p == null || found.isEmpty()) return;
        BlockPos me = p.getBlockPos();

        if (list.v) {
            Hud.left(ctx, mc, "Spawner: " + found.size(), color.argb());
            for (int i = 0; i < Math.min(5, found.size()); i++) {
                SpawnerScan.Spawner s = found.get(i);
                int d = (int) Math.sqrt(s.pos.getSquaredDistance(me));
                Hud.left(ctx, mc, " " + s.type + "  " + s.pos.getX() + " " + s.pos.getY() + " " + s.pos.getZ()
                        + "  (" + d + "m)", 0xFFE0E0E0);
            }
        }

        WorldCam cam = WorldCam.current(mc, tickProgress);
        int col = color.argb();
        int lineCol = color.argb(0xD0);
        int n = Math.min(20, found.size());
        for (int i = 0; i < n; i++) {
            BlockPos b = found.get(i).pos;
            double cx = b.getX() + 0.5;
            double cy = b.getY() + 0.5;
            double cz = b.getZ() + 0.5;

            if (beam.v) cam.line(ctx, cx, cy - 96, cz, cx, cy + 96, cz, lineCol, 2);
            if (chunkBox.v) {
                double x0 = (b.getX() >> 4) * 16.0;
                double z0 = (b.getZ() >> 4) * 16.0;
                double x1 = x0 + 16;
                double z1 = z0 + 16;
                int boxCol = color.argb(0x90);
                cam.line(ctx, x0, cy, z0, x1, cy, z0, boxCol, 1);
                cam.line(ctx, x1, cy, z0, x1, cy, z1, boxCol, 1);
                cam.line(ctx, x1, cy, z1, x0, cy, z1, boxCol, 1);
                cam.line(ctx, x0, cy, z1, x0, cy, z0, boxCol, 1);
            }
            double[] s = cam.project(cx, cy, cz);
            if (s != null) {
                int px = (int) s[0];
                int py = (int) s[1];
                ctx.fill(px - 3, py - 3, px + 4, py + 4, col);
                ctx.fill(px - 1, py - 1, px + 2, py + 2, 0xFFFFFFFF);
            }
        }
    }
}
