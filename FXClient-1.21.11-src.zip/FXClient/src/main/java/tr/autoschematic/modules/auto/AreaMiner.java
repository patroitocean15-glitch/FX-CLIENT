package tr.autoschematic.modules.auto;

import net.minecraft.block.BlockState;
import net.minecraft.block.FluidBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;
import tr.autoschematic.gui.Hud;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Erişebildiği alandaki blokları sırayla kırar (yürümez; sen alanın içinde dolaşırsın). */
public final class AreaMiner extends Feature {
    public static BlockPos pos1;
    public static BlockPos pos2;

    private final Setting.Mode mode = add(new Setting.Mode("Alan türü", "Yarıçap", "Pos1-Pos2 kutusu"));
    private final Setting.Num radius = add(new Setting.Num("Yarıçap", 4, 1, 5, 1));
    private final Setting.Bool topDown = add(new Setting.Bool("Üstten alta", true));
    private final Setting.Bool autoTool = add(new Setting.Bool("Otomatik alet seç", true));
    private final Setting.Bool skipBe = add(new Setting.Bool("Sandık/fırın vb. atla", true));
    private final Setting.Bool keepFloor = add(new Setting.Bool("Bastığım bloğu kırma", true));
    @SuppressWarnings("unused")
    private final Setting.Action setP1 = add(new Setting.Action("Pos1 = bastığım blok", () -> pos1 = here()));
    @SuppressWarnings("unused")
    private final Setting.Action setP2 = add(new Setting.Action("Pos2 = bastığım blok", () -> pos2 = here()));
    @SuppressWarnings("unused")
    private final Setting.Action clear = add(new Setting.Action("Pos1/Pos2 temizle", () -> {
        pos1 = null;
        pos2 = null;
    }));

    private BlockPos target;

    public AreaMiner() {
        super("Auto Area Miner",
                "Menzildeki blokları otomatik kırar. Alanı yarıçapla ya da Pos1-Pos2 kutusuyla belirle.",
                Category.AUTO);
    }

    private static BlockPos here() {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        return p == null ? null : p.getBlockPos().down();
    }

    @Override
    public void onDisable() {
        target = null;
        ClientPlayerInteractionManager im = MinecraftClient.getInstance().interactionManager;
        if (im != null) im.cancelBlockBreaking();
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        ClientPlayerInteractionManager im = mc.interactionManager;
        if (p == null || w == null || im == null || mc.currentScreen != null || p.isSpectator()) return;

        double reach = p.getBlockInteractionRange() - 0.4;
        Vec3d eye = p.getEyePos();

        if (target != null) {
            BlockState st = w.getBlockState(target);
            if (st.isAir() || eye.squaredDistanceTo(Vec3d.ofCenter(target)) > reach * reach) {
                target = null;
            }
        }
        if (target == null) {
            target = pick(p, w, eye, reach);
            if (target == null) return;
        }

        BlockState st = w.getBlockState(target);
        if (autoTool.v) selectTool(p, st);
        Direction face = Direction.getFacing(
                eye.x - (target.getX() + 0.5), eye.y - (target.getY() + 0.5), eye.z - (target.getZ() + 0.5));
        if (im.updateBlockBreakingProgress(target, face)) {
            p.swingHand(Hand.MAIN_HAND);
        }
    }

    private BlockPos pick(ClientPlayerEntity p, ClientWorld w, Vec3d eye, double reach) {
        boolean box = mode.idx == 1;
        if (box && (pos1 == null || pos2 == null)) return null;

        int r = (int) Math.ceil(reach);
        if (!box) r = Math.min(r, radius.i());
        BlockPos base = p.getBlockPos();
        BlockPos floor = base.down();
        List<BlockPos> cands = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    BlockPos pos = base.add(dx, dy, dz);
                    if (box && !inBox(pos)) continue;
                    if (eye.squaredDistanceTo(Vec3d.ofCenter(pos)) > reach * reach) continue;
                    BlockState st = w.getBlockState(pos);
                    if (st.isAir() || st.getBlock() instanceof FluidBlock) continue;
                    if (st.getHardness(w, pos) < 0) continue;
                    if (skipBe.v && st.hasBlockEntity()) continue;
                    if (keepFloor.v && pos.equals(floor)) continue;
                    cands.add(pos);
                }
            }
        }
        if (cands.isEmpty()) return null;

        Comparator<BlockPos> byDist =
                Comparator.comparingDouble((BlockPos b) -> eye.squaredDistanceTo(Vec3d.ofCenter(b)));
        Comparator<BlockPos> cmp = topDown.v
                ? Comparator.comparingInt((BlockPos b) -> -b.getY()).thenComparing(byDist)
                : byDist;
        cands.sort(cmp);
        return cands.get(0);
    }

    private static boolean inBox(BlockPos p) {
        int minX = Math.min(pos1.getX(), pos2.getX());
        int maxX = Math.max(pos1.getX(), pos2.getX());
        int minY = Math.min(pos1.getY(), pos2.getY());
        int maxY = Math.max(pos1.getY(), pos2.getY());
        int minZ = Math.min(pos1.getZ(), pos2.getZ());
        int maxZ = Math.max(pos1.getZ(), pos2.getZ());
        return p.getX() >= minX && p.getX() <= maxX
                && p.getY() >= minY && p.getY() <= maxY
                && p.getZ() >= minZ && p.getZ() <= maxZ;
    }

    private static void selectTool(ClientPlayerEntity p, BlockState st) {
        PlayerInventory inv = p.getInventory();
        int best = -1;
        float bestSpeed = 1.0f;
        for (int i = 0; i < 9; i++) {
            float sp = inv.getStack(i).getMiningSpeedMultiplier(st);
            if (sp > bestSpeed) {
                bestSpeed = sp;
                best = i;
            }
        }
        if (best >= 0 && best != inv.getSelectedSlot()) inv.setSelectedSlot(best);
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc, float tickProgress) {
        if (mode.idx == 1 && (pos1 == null || pos2 == null)) {
            Hud.left(ctx, mc, "Area Miner: Pos1 ve Pos2'yi GUI'den ayarla", 0xFFFFD166);
        } else {
            Hud.left(ctx, mc, "Area Miner: " + (target == null ? "hedef yok" : "kırılıyor"), 0xFF9AA0AE);
        }
    }
}
