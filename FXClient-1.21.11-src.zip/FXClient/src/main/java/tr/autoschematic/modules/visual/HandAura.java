package tr.autoschematic.modules.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Arm;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Features;
import tr.autoschematic.core.Setting;

/**
 * El ve eşya çevresinde renkli parlama + parıltı (rengi GUI'den seçilir) ve ayrı bir el FOV'u (varsayılan 130).
 * El FOV'u, el çizim matrisi ölçeklenerek uygulanır; eli küçültür ama görünür tutar ("El boyutu telafisi").
 * Not: parlama ekrana çizilen bir efekttir (shader değildir); eşyanın tahmini ekran konumunu izler.
 */
public final class HandAura extends Feature {
    public final Setting.Color color = add(new Setting.Color("Aura rengi", 0x8EC9FF));
    public final Setting.Num density = add(new Setting.Num("Parıltı yoğunluğu", 14, 2, 40, 1));
    public final Setting.Num glow = add(new Setting.Num("Parlama gücü", 45, 0, 100, 5));
    public final Setting.Num speed = add(new Setting.Num("Hareket hızı", 1.0, 0.3, 3.0, 0.1));
    public final Setting.Bool handFov = add(new Setting.Bool("El FOV'u uygula", true));
    public final Setting.Num fov = add(new Setting.Num("El FOV", 130, 30, 170, 5));
    public final Setting.Num boost = add(new Setting.Num("El boyutu telafisi", 1.6, 0.5, 3.0, 0.1));

    public HandAura() {
        super("Hand Aura", "El ve eşya çevresinde renkli parlama/parıltı. Ayrıca ayrı bir el FOV'u uygular (varsayılan 130).",
                Category.VISUALS);
    }

    /** El FOV'una karşılık gelen küçültme oranı (1 = değişiklik yok). */
    public float fovScale(MinecraftClient mc) {
        if (!handFov.v) return 1f;
        double base = mc.options.getFov().getValue();
        double s = Math.tan(Math.toRadians(base) / 2.0) / Math.tan(Math.toRadians(fov.v) / 2.0);
        return (float) Math.max(0.15, Math.min(4.0, s));
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc, float tickProgress) {
        ClientPlayerEntity p = mc.player;
        if (p == null || !mc.options.getPerspective().isFirstPerson()) return;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        // --- eşyanın tahmini ekran merkezi ---
        double side = p.getMainArm() == Arm.RIGHT ? 1.0 : -1.0;
        double baseFov = mc.options.getFov().getValue();
        double tyBase = Math.tan(Math.toRadians(baseFov) / 2.0);
        double txBase = tyBase * ((double) sw / sh);
        double dz = 0.72;                                   // eşyanın kameraya yaklaşık uzaklığı
        double px = (0.5 + 0.32 * side) * sw;               // vanilla: sağ elde yaklaşık (0.82W, 0.86H)
        double py = 0.86 * sh;

        HandView hv = Features.HAND_VIEW;
        BetterItem bi = Features.BETTER_ITEM;
        if (hv.enabled) {
            px += (hv.x.v * side) / (dz * txBase) * (sw / 2.0);
            py -= hv.y.v / (dz * tyBase) * (sh / 2.0);
        }
        if (bi.enabled) py -= bi.hover.v / (dz * tyBase) * (sh / 2.0);

        double s = fovScale(mc);
        double cx = sw / 2.0;
        double cy = sh / 2.0;
        px = cx + (px - cx) * s;
        py = cy + (py - cy) * s;

        double size = s * (handFov.v ? boost.v : 1.0) * (hv.enabled ? hv.scale.v : 1.0);
        double rx = sw * 0.07 * size;
        double ry = sh * 0.11 * size;

        long now = System.currentTimeMillis();
        double t = now / 1000.0 * speed.v;
        double pulse = 0.75 + 0.25 * Math.sin(t * 3.0);

        // --- yumuşak parlama: içiçe yarı saydam elipsler ---
        if (glow.v > 0) {
            int layers = 6;
            for (int i = 0; i < layers; i++) {
                double f = 1.0 - i / (double) layers;
                double a = (glow.v / 100.0) * (0.10 + 0.45 * (i / (double) layers)) * pulse;
                int alpha = (int) Math.max(0, Math.min(90, a * 90));
                int col = color.argb(alpha);
                double erx = rx * f;
                double ery = ry * f;
                for (double dy = -ery; dy <= ery; dy += 2.0) {
                    double half = erx * Math.sqrt(Math.max(0.0, 1.0 - (dy * dy) / (ery * ery)));
                    ctx.fill((int) (px - half), (int) (py + dy), (int) (px + half), (int) (py + dy + 2), col);
                }
            }
        }

        // --- parıltılar: elips kenarında doğup sönen yıldızlar ---
        int n = density.i();
        for (int i = 0; i < n; i++) {
            double period = 0.7 + ((i * 137) % 500) / 1000.0;
            double shifted = t + i * 0.311;
            double phase = shifted % period;
            long cycle = (long) Math.floor(shifted / period);
            double life = phase / period;
            double alpha = Math.sin(life * Math.PI);
            long seed = cycle * 7919L + i * 104729L;
            double ang = ((seed * 31 + 7) % 3600) / 3600.0 * Math.PI * 2.0;
            double rad = 0.65 + ((seed * 17 + 3) % 1000) / 1000.0 * 0.5;
            int x = (int) (px + Math.cos(ang) * rx * rad);
            int y = (int) (py + Math.sin(ang) * ry * rad);
            int size2 = 1 + (int) (seed % 3);
            int a = (int) (alpha * 235);
            ctx.fill(x - size2, y, x + size2 + 1, y + 1, color.argb(a));
            ctx.fill(x, y - size2, x + 1, y + size2 + 1, color.argb(a));
            ctx.fill(x, y, x + 1, y + 1, (a << 24) | 0xFFFFFF);
        }
    }
}
