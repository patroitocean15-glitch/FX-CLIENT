package tr.autoschematic.modules.auto;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import tr.autoschematic.Util;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;
import tr.autoschematic.gui.Draw;

import java.util.HashSet;
import java.util.Set;

/** Yeni bir spawner bulunduğunda sohbete yazar, ekranda büyük uyarı gösterir ve ses çalar. */
public final class SpawnerNotifier extends Feature {
    private final Setting.Num chunks = add(new Setting.Num("Tarama yarıçapı (chunk)", 12, 2, 32, 1));
    private final Setting.Bool chat = add(new Setting.Bool("Sohbete yaz", true));
    private final Setting.Bool title = add(new Setting.Bool("Ekranda büyük uyarı", true));
    private final Setting.Bool sound = add(new Setting.Bool("Ses çal", true));

    private final Set<Long> announced = new HashSet<>();
    private ClientWorld lastWorld;
    private int flash;
    private String flashText = "";

    public SpawnerNotifier() {
        super("Auto Spawner Notifier",
                "Yeni spawner bulununca sohbete yazar, ekranda uyarır ve ses çalar (mob türüyle birlikte).",
                Category.AUTO);
    }

    @Override
    public void onDisable() {
        announced.clear();
        flash = 0;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) return;
        if (mc.world != lastWorld) {          // dünya/boyut değişti
            lastWorld = mc.world;
            announced.clear();
        }
        if (flash > 0) flash--;
        SpawnerScan.tick(mc, chunks.i());

        BlockPos me = p.getBlockPos();
        for (SpawnerScan.Spawner s : SpawnerScan.list) {
            if (!announced.add(s.pos.asLong())) continue;
            int d = (int) Math.sqrt(s.pos.getSquaredDistance(me));
            String xyz = s.pos.getX() + " " + s.pos.getY() + " " + s.pos.getZ();
            String msg = s.type + " spawner: " + xyz + " (" + d + "m)";
            if (chat.v) Util.chat(mc, Text.literal("[FX] " + msg).formatted(Formatting.RED));
            Util.info(mc, msg);
            if (title.v) {
                flash = 80;
                flashText = msg;
            }
            if (sound.v) p.playSound(SoundEvents.ENTITY_PLAYER_LEVELUP, 1.0f, 1.2f);
        }
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc, float tickProgress) {
        if (flash > 0 && (flash / 6) % 2 == 0) {
            Draw.center(ctx, mc.textRenderer, "[!] " + flashText, mc.getWindow().getScaledWidth() / 2, 34, 0xFFFF4D4D);
        }
    }
}
