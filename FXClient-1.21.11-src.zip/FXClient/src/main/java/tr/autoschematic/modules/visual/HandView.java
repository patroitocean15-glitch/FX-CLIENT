package tr.autoschematic.modules.visual;

import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;

/** Birinci şahıs el/eşya konumu, boyutu ve açısı. Çizimi VisualFx + HeldItemRendererMixin yapar. */
public final class HandView extends Feature {
    public final Setting.Num x = add(new Setting.Num("Sağ-sol (X)", 0, -1.0, 1.0, 0.05));
    public final Setting.Num y = add(new Setting.Num("Yukarı-aşağı (Y)", 0, -1.0, 1.0, 0.05));
    public final Setting.Num z = add(new Setting.Num("İleri-geri (Z)", 0, -1.0, 1.0, 0.05));
    public final Setting.Num scale = add(new Setting.Num("Boyut", 1.0, 0.2, 2.0, 0.05));
    public final Setting.Num rotX = add(new Setting.Num("Döndür X", 0, -180, 180, 5));
    public final Setting.Num rotY = add(new Setting.Num("Döndür Y", 0, -180, 180, 5));
    public final Setting.Num rotZ = add(new Setting.Num("Döndür Z", 0, -180, 180, 5));

    public HandView() {
        super("Hand View", "Elin ve elindeki eşyanın konumunu, boyutunu ve açısını ayarlar.", Category.VISUALS);
    }
}
