package tr.autoschematic.modules.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;
import tr.autoschematic.gui.WorldCam;

/** Bulunduğun chunk'ın ve çevresindeki chunk sınırlarını ekrana çizer. */
public final class ChunkBorders extends Feature {
    private final Setting.Num radius = add(new Setting.Num("Chunk yarıçapı", 1, 0, 3, 1));
    private final Setting.Num height = add(new Setting.Num("Dikey çizgi yüksekliği", 24, 8, 128, 4));
    private final Setting.Color color = add(new Setting.Color("Renk", 0xFFD166));

    public ChunkBorders() {
        super("Chunk Borders", "Bulunduğun chunk'ın sınırlarını (ve çevresini) ekranda gösterir.", Category.VISUALS);
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc, float tickProgress) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        WorldCam cam = WorldCam.current(mc, tickProgress);
        int cx = p.getBlockX() >> 4;
        int cz = p.getBlockZ() >> 4;
        int r = radius.i();
        double y = p.getY();
        int col = color.argb(0xB0);

        double xMin = (cx - r) * 16.0;
        double xMax = (cx + r + 1) * 16.0;
        double zMin = (cz - r) * 16.0;
        double zMax = (cz + r + 1) * 16.0;
        for (int i = -r; i <= r + 1; i++) {                     // ızgara çizgileri (ayak hizasında)
            double x = (cx + i) * 16.0;
            double z = (cz + i) * 16.0;
            cam.line(ctx, x, y, zMin, x, y, zMax, col, 1);
            cam.line(ctx, xMin, y, z, xMax, y, z, col, 1);
        }
        double x0 = cx * 16.0;
        double z0 = cz * 16.0;
        double[][] corners = {{x0, z0}, {x0 + 16, z0}, {x0, z0 + 16}, {x0 + 16, z0 + 16}};
        for (double[] c : corners) {                            // bulunduğun chunk'ın köşe direkleri
            cam.line(ctx, c[0], y - height.v, c[1], c[0], y + height.v, c[1], col, 1);
        }
    }
}
