package tr.autoschematic.modules.misc;

import org.lwjgl.glfw.GLFW;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;

/** Menü teması ve menüyü açan tuş (varsayılan: Sağ Shift). Varsayılan tema: gri. */
public final class GuiFeature extends Feature {
    private static final int[] PRESETS = {
            0xB9BCC4, 0xDADDE3, 0x7D818B, 0x8FA3B8, 0x3FA9F5, 0x9B6BFF, 0xFF4D4D, 0x3DDC84, 0xFF9F43};

    public final Setting.Mode preset = add(new Setting.Mode("Hazır tema",
            "Gri (FX)", "Gümüş", "Grafit", "Mavi-gri", "Mavi", "Mor", "Kırmızı", "Yeşil", "Turuncu", "Özel"));
    public final Setting.Color accent = add(new Setting.Color("Vurgu rengi", 0xB9BCC4));
    public final Setting.Num opacity = add(new Setting.Num("Arka plan opaklığı", 235, 90, 255, 5));
    public final Setting.Num radius = add(new Setting.Num("Köşe yuvarlaklığı", 4, 0, 8, 1));
    public final Setting.Bool dim = add(new Setting.Bool("Arkaplanı karart", true));

    public GuiFeature() {
        super("GUI", "FX Client menü rengi, opaklığı ve köşeleri. Menüyü açan tuşu aşağıdaki 'Tuş' kutusundan değiştirebilirsin.",
                Category.THEME);
        key = GLFW.GLFW_KEY_RIGHT_SHIFT;
        enabled = true;
        preset.onChange = () -> {
            if (preset.idx < PRESETS.length) accent.rgb = PRESETS[preset.idx];
        };
        accent.onChange = () -> preset.idx = PRESETS.length;
    }

    @Override
    public boolean toggleable() {
        return false;
    }
}
