package tr.autoschematic.modules.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import tr.autoschematic.Staff;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;
import tr.autoschematic.gui.Hud;

import java.util.List;

/** Tab listesindeki yetkili/rank'lı oyuncuları köşede listeler. */
public final class StaffList extends Feature {
    private final Setting.Bool anyRank = add(new Setting.Bool("Rank'ı olan herkes", false));
    private final Setting.Mode corner = add(new Setting.Mode("Konum", "Sağ üst", "Sol üst"));
    private int t;

    public StaffList() {
        super("Staff List", "Tab listesinde yetkili/rank'ı olan çevrimiçi oyuncuları ve rank'larını gösterir.",
                Category.MISC);
    }

    @Override
    public void onEnable() {
        t = 0;
        Staff.refresh(MinecraftClient.getInstance(), anyRank.v);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (++t % 20 == 0) Staff.refresh(mc, anyRank.v);
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc, float tickProgress) {
        List<Staff.Entry> list = Staff.list;
        boolean right = corner.idx == 0;
        String head = "Staff (" + list.size() + ")";
        if (right) Hud.right(ctx, mc, Text.literal(head), 0xFFFFD166);
        else Hud.left(ctx, mc, head, 0xFFFFD166);
        int n = 0;
        for (Staff.Entry e : list) {
            if (n++ >= 10) break;
            Text line = Text.empty().append(e.shown)
                    .append(Text.literal(" [" + e.rank + "]").formatted(Formatting.GRAY));
            if (right) Hud.right(ctx, mc, line, 0xFFFFFFFF);
            else Hud.left(ctx, mc, line.getString(), 0xFFFFFFFF);
        }
    }
}
