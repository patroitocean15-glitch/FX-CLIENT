package tr.autoschematic.modules.auto;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;
import tr.autoschematic.gui.Draw;
import tr.autoschematic.gui.WorldCam;

import java.util.List;

/** Spawner'ların üstüne mob türünü ve mesafeyi yazan isim etiketleri (duvarın arkasından da görünür). */
public final class SpawnerNameTags extends Feature {
    private final Setting.Num chunks = add(new Setting.Num("Tarama yarıçapı (chunk)", 12, 2, 32, 1));
    private final Setting.Num range = add(new Setting.Num("Etiket mesafesi (blok)", 128, 16, 512, 16));
    private final Setting.Bool distance = add(new Setting.Bool("Mesafeyi göster", true));
    private final Setting.Bool background = add(new Setting.Bool("Etiket arka planı", true));
    private final Setting.Color color = add(new Setting.Color("Yazı rengi", 0xFFD166));

    public SpawnerNameTags() {
        super("Spawner Name Tags", "Spawner'ların üstünde mob türünü (Zombie, Cave Spider...) ve mesafeyi gösterir.",
                Category.AUTO);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        SpawnerScan.tick(mc, chunks.i());
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc, float tickProgress) {
        ClientPlayerEntity p = mc.player;
        List<SpawnerScan.Spawner> found = SpawnerScan.list;
        if (p == null || found.isEmpty()) return;
        WorldCam cam = WorldCam.current(mc, tickProgress);
        double lim = range.v * range.v;
        int shown = 0;
        for (SpawnerScan.Spawner s : found) {
            if (shown >= 30) break;
            double d2 = s.pos.getSquaredDistance(p.getBlockPos());
            if (d2 > lim) continue;
            double[] sc = cam.project(s.pos.getX() + 0.5, s.pos.getY() + 1.4, s.pos.getZ() + 0.5);
            if (sc == null) continue;
            String label = s.type + " Spawner" + (distance.v ? "  " + (int) Math.sqrt(d2) + "m" : "");
            int w = mc.textRenderer.getWidth(label);
            int x = (int) sc[0] - w / 2;
            int y = (int) sc[1];
            if (background.v) ctx.fill(x - 3, y - 2, x + w + 3, y + 10, 0x99000000);
            Draw.text(ctx, mc.textRenderer, label, x, y, color.argb());
            shown++;
        }
    }
}
