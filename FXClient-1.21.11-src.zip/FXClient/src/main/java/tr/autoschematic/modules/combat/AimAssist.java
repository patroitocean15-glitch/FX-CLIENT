package tr.autoschematic.modules.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.ZombifiedPiglinEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;

/** Düşman moblara doğru bakışı yumuşakça çeker (sadece moblar; oyuncuları hedeflemez). */
public final class AimAssist extends Feature {
    private final Setting.Num range = add(new Setting.Num("Menzil", 6.0, 3.0, 16.0, 0.5));
    private final Setting.Num fov = add(new Setting.Num("Görüş konisi (°)", 90, 20, 180, 5));
    private final Setting.Num smooth = add(new Setting.Num("Yumuşatma (büyük = yavaş)", 8, 2, 30, 1));
    private final Setting.Bool onlyAttack = add(new Setting.Bool("Sadece sol tık basılıyken", true));
    private final Setting.Bool skipSpecial = add(new Setting.Bool("Enderman / zombi piglin'i atla", true));

    public AimAssist() {
        super("Aim Assist (Mob)", "Düşman moblara doğru bakışı yumuşakça çeker. Sadece moblar; oyuncuları hedeflemez.",
                Category.COMBAT);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null || mc.currentScreen != null || p.isSpectator()) return;
        if (onlyAttack.v && !mc.options.attackKey.isPressed()) return;

        Vec3d eye = p.getEyePos();
        HostileEntity best = null;
        double bestAngle = Double.MAX_VALUE;
        float bestYaw = 0f;
        float bestPitch = 0f;
        for (Entity e : w.getEntities()) {
            if (!(e instanceof HostileEntity h) || !h.isAlive()) continue;
            if (skipSpecial.v && (h instanceof EndermanEntity || h instanceof ZombifiedPiglinEntity)) continue;
            if (p.distanceTo(h) > range.v || !p.canSee(h)) continue;

            double dx = h.getX() - eye.x;
            double dy = (h.getY() + h.getHeight() * 0.6) - eye.y;
            double dz = h.getZ() - eye.z;
            float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
            float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
            float dYaw = MathHelper.wrapDegrees(yaw - p.getYaw());
            if (Math.abs(dYaw) > fov.v / 2.0) continue;
            double angle = Math.abs(dYaw) + Math.abs(pitch - p.getPitch());
            if (angle < bestAngle) {
                bestAngle = angle;
                best = h;
                bestYaw = yaw;
                bestPitch = pitch;
            }
        }
        if (best == null) return;

        float dYaw = MathHelper.wrapDegrees(bestYaw - p.getYaw());
        float dPitch = bestPitch - p.getPitch();
        p.setYaw(p.getYaw() + dYaw / smooth.f());
        p.setPitch(MathHelper.clamp(p.getPitch() + dPitch / smooth.f(), -90f, 90f));
    }
}
