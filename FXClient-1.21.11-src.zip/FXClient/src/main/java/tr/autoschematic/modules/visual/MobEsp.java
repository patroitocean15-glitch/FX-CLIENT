package tr.autoschematic.modules.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;
import tr.autoschematic.gui.Draw;
import tr.autoschematic.gui.WorldCam;

/** Moblar (düşman ve/veya hayvan) için ekran kutusu + isim etiketi. Oyuncular dahil DEĞİLDİR. */
public final class MobEsp extends Feature {
    private final Setting.Bool hostile = add(new Setting.Bool("Düşman moblar", true));
    private final Setting.Bool passive = add(new Setting.Bool("Hayvan / pasif moblar", false));
    private final Setting.Num range = add(new Setting.Num("Mesafe (blok)", 48, 8, 128, 8));
    private final Setting.Bool labels = add(new Setting.Bool("İsim + mesafe", true));
    private final Setting.Bool tracers = add(new Setting.Bool("Çizgi (tracer)", false));
    private final Setting.Color hostileColor = add(new Setting.Color("Düşman rengi", 0xFF4D4D));
    private final Setting.Color passiveColor = add(new Setting.Color("Pasif rengi", 0x4DFF88));

    public MobEsp() {
        super("Mob ESP", "Moblar için ekran kutusu ve etiket (duvarın arkasından da görünür). Oyuncuları göstermez.",
                Category.VISUALS);
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc, float tickProgress) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null) return;
        WorldCam cam = WorldCam.current(mc, tickProgress);
        double lim = range.v;
        int count = 0;
        for (Entity e : w.getEntities()) {
            if (count >= 60) break;
            if (!(e instanceof MobEntity m) || !m.isAlive()) continue;
            boolean isHostile = m instanceof Monster;
            if (isHostile ? !hostile.v : !passive.v) continue;
            double dist = p.distanceTo(m);
            if (dist > lim) continue;

            double x = m.getX();
            double y = m.getY();
            double z = m.getZ();
            double h = m.getHeight();
            double[] feet = cam.project(x, y, z);
            double[] head = cam.project(x, y + h, z);
            if (feet == null || head == null) continue;

            int col = (isHostile ? hostileColor : passiveColor).argb();
            int top = (int) Math.min(feet[1], head[1]);
            int bottom = (int) Math.max(feet[1], head[1]);
            int boxH = Math.max(6, bottom - top);
            int boxW = Math.max(4, (int) (boxH * 0.5));
            int cx = (int) feet[0];
            int left = cx - boxW / 2;
            int right = cx + boxW / 2;
            ctx.fill(left, top, right, top + 1, col);
            ctx.fill(left, bottom, right, bottom + 1, col);
            ctx.fill(left, top, left + 1, bottom, col);
            ctx.fill(right, top, right + 1, bottom + 1, col);

            if (labels.v) {
                String label = m.getName().getString() + "  " + (int) dist + "m";
                Draw.center(ctx, mc.textRenderer, label, cx, top - 11, col);
            }
            if (tracers.v) {
                Draw.line(ctx, cam.sw / 2.0, cam.sh, cx, bottom, cam.sw, cam.sh, (col & 0x00FFFFFF) | 0x99000000, 1);
            }
            count++;
        }
    }
}
