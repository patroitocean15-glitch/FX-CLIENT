package tr.autoschematic.modules.visual;

import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;

/** Yakınlaştırma. Tuş atayıp "Basılı tut" modunda kullanmak için tasarlandı. FOV'u VisualFx değiştirir. */
public final class Zoom extends Feature {
    public final Setting.Num fov = add(new Setting.Num("Zoom FOV", 30, 5, 60, 1));

    public Zoom() {
        super("Zoom", "Basılı tutarken yakınlaştırır (tuş ata). FOV değerini ayarlayabilirsin.", Category.VISUALS);
        hold = true;
    }
}
