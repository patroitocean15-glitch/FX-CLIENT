package tr.autoschematic.modules.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import tr.autoschematic.Util;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;

/** Offhand'de totem yoksa envanterden (hotbar dahil) bir totemi offhand'e koyar. */
public final class AutoTotem extends Feature {
    private final Setting.Num delay = add(new Setting.Num("Gecikme (tick)", 1, 0, 10, 1));
    private final Setting.Bool lowOnly = add(new Setting.Bool("Sadece düşük canda", false));
    private final Setting.Num health = add(new Setting.Num("Can eşiği (<=)", 10, 1, 20, 1));
    private int wait;

    public AutoTotem() {
        super("Auto Totem", "Offhand'de totem yoksa envanterden otomatik koyar (totem patlayınca yenisi gelir).",
                Category.COMBAT);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientPlayerInteractionManager im = mc.interactionManager;
        if (p == null || im == null) return;
        if (p.currentScreenHandler != p.playerScreenHandler) return;
        if (!p.playerScreenHandler.getCursorStack().isEmpty()) return;

        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
            wait = 0;
            return;
        }
        if (lowOnly.v && p.getHealth() + p.getAbsorptionAmount() > health.v) return;
        if (wait > 0) {
            wait--;
            return;
        }
        int found = Util.findItem(p, Items.TOTEM_OF_UNDYING, 0, 36);
        if (found < 0) return;

        // SWAP + 40 = seçilen slot ile offhand'i değiştir
        im.clickSlot(p.playerScreenHandler.syncId, Util.screenSlot(found), 40, SlotActionType.SWAP, p);
        wait = delay.i();
    }
}
