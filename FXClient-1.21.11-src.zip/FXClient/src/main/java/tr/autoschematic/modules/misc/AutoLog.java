package tr.autoschematic.modules.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.text.Text;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;

/** Canın eşiğin altına düşerse sunucudan çıkar (AFK güvenliği). */
public final class AutoLog extends Feature {
    private final Setting.Num health = add(new Setting.Num("Can eşiği (<=)", 6, 1, 19, 1));

    public AutoLog() {
        super("Auto Log", "Canın eşiğin altına düşerse sunucudan çıkar; çıkış ekranında nedeni yazar.", Category.MISC);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        float hp = p.getHealth() + p.getAbsorptionAmount();
        if (hp > 0 && hp <= health.v) {
            ClientPlayNetworkHandler h = mc.getNetworkHandler();
            setEnabled(false);
            if (h != null) {
                h.getConnection().disconnect(Text.literal("Auto Log: can " + Math.round(hp) + " (eşik " + health.i() + ")"));
            }
        }
    }
}
