package tr.autoschematic.modules.auto;

import net.minecraft.client.MinecraftClient;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;

/** İleri tuşunu basılı tutar (AFK madencilik/çiftlik için). Kapatınca bırakır. */
public final class AutoWalk extends Feature {
    public AutoWalk() {
        super("Auto Walk", "Sürekli ileri yürür (ileri tuşu basılı tutulmuş gibi).", Category.AUTO);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen == null) mc.options.forwardKey.setPressed(true);
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options != null) mc.options.forwardKey.setPressed(false);
    }
}
