package tr.autoschematic.modules.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.ZombifiedPiglinEntity;
import net.minecraft.util.Hand;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;

/**
 * Menzildeki DÜŞMAN MOBLARA otomatik vurur (grind/mob farm için). Oyuncuları hedeflemez.
 */
public final class KillAura extends Feature {
    private final Setting.Num range = add(new Setting.Num("Menzil", 3.0, 1.5, 6.0, 0.1));
    private final Setting.Bool skipEnderman = add(new Setting.Bool("Enderman'ı atla", true));
    private final Setting.Bool skipPiglin = add(new Setting.Bool("Zombi piglin'i atla", true));
    private final Setting.Bool needSight = add(new Setting.Bool("Görüş hattı gerekli", true));

    public KillAura() {
        super("Kill Aura", "Menzildeki düşman moblara otomatik vurur. Sadece mob; oyunculara vurmaz.",
                Category.COMBAT);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        ClientPlayerInteractionManager im = mc.interactionManager;
        if (p == null || w == null || im == null || mc.currentScreen != null) return;
        if (p.isSpectator() || p.getAttackCooldownProgress(0.5f) < 1.0f) return;

        HostileEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : w.getEntities()) {
            if (!(e instanceof HostileEntity h) || !h.isAlive()) continue;
            if (skipEnderman.v && h instanceof EndermanEntity) continue;
            if (skipPiglin.v && h instanceof ZombifiedPiglinEntity) continue;
            double d = p.distanceTo(h);
            if (d > range.v || d >= bestDist) continue;
            if (needSight.v && !p.canSee(h)) continue;
            best = h;
            bestDist = d;
        }
        if (best == null) return;
        im.attackEntity(p, best);
        p.swingHand(Hand.MAIN_HAND);
    }
}
