package tr.autoschematic.modules.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import tr.autoschematic.Util;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Features;
import tr.autoschematic.core.Setting;
import tr.autoschematic.gui.Draw;
import tr.autoschematic.gui.Hud;
import tr.autoschematic.gui.WorldCam;

import java.util.ArrayList;
import java.util.List;

/** Koordinat kaydeder; ekranda işaret + mesafe gösterir. Veriler config dosyasında saklanır. */
public final class Waypoints extends Feature {
    private final Setting.Bool markers = add(new Setting.Bool("Ekranda işaret", true));
    private final Setting.Bool list = add(new Setting.Bool("Listeyi göster", true));
    private final Setting.Num maxShown = add(new Setting.Num("En fazla gösterilen", 6, 1, 20, 1));
    private final Setting.Color color = add(new Setting.Color("Renk", 0x7FD6FF));
    @SuppressWarnings("unused")
    private final Setting.Action saveHere = add(new Setting.Action("Şu anki konumu kaydet", Waypoints::saveHere));
    @SuppressWarnings("unused")
    private final Setting.Action delLast = add(new Setting.Action("Sonuncuyu sil", Waypoints::deleteLast));
    @SuppressWarnings("unused")
    private final Setting.Action delAll = add(new Setting.Action("Hepsini sil", Waypoints::deleteAll));

    public Waypoints() {
        super("Waypoints", "Konumları kaydeder; ekranda işaret ve mesafe gösterir (boyuta göre ayrı).", Category.VISUALS);
    }

    private static String dim(MinecraftClient mc) {
        return mc.world == null ? "?" : mc.world.getRegistryKey().getValue().toString();
    }

    private static void saveHere() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        String name = "WP" + (Features.data.waypoints.size() + 1);
        Features.data.waypoints.add(name + "|" + p.getBlockX() + "|" + p.getBlockY() + "|" + p.getBlockZ() + "|" + dim(mc));
        Features.save();
        Util.info(mc, "Waypoint kaydedildi: " + name);
    }

    private static void deleteLast() {
        List<String> l = Features.data.waypoints;
        if (!l.isEmpty()) l.remove(l.size() - 1);
        Features.save();
    }

    private static void deleteAll() {
        Features.data.waypoints.clear();
        Features.save();
    }

    private static final class Wp {
        String name;
        int x;
        int y;
        int z;
        double dist;
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc, float tickProgress) {
        ClientPlayerEntity p = mc.player;
        if (p == null || Features.data.waypoints.isEmpty()) return;
        String d = dim(mc);
        List<Wp> out = new ArrayList<>();
        for (String s : Features.data.waypoints) {
            String[] a = s.split("\\|");
            if (a.length < 5 || !a[4].equals(d)) continue;
            try {
                Wp w = new Wp();
                w.name = a[0];
                w.x = Integer.parseInt(a[1]);
                w.y = Integer.parseInt(a[2]);
                w.z = Integer.parseInt(a[3]);
                double dx = w.x + 0.5 - p.getX();
                double dy = w.y + 0.5 - p.getY();
                double dz = w.z + 0.5 - p.getZ();
                w.dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
                out.add(w);
            } catch (NumberFormatException ignored) {
                // bozuk kayıt
            }
        }
        out.sort((a, b) -> Double.compare(a.dist, b.dist));

        int col = color.argb();
        WorldCam cam = WorldCam.current(mc, tickProgress);
        int n = Math.min(maxShown.i(), out.size());
        if (list.v && n > 0) Hud.left(ctx, mc, "Waypoints:", col);
        for (int i = 0; i < n; i++) {
            Wp w = out.get(i);
            String label = w.name + "  " + (int) w.dist + "m";
            if (list.v) Hud.left(ctx, mc, " " + label + "  (" + w.x + " " + w.y + " " + w.z + ")", 0xFFE0E0E0);
            if (markers.v) {
                double[] sc = cam.project(w.x + 0.5, w.y + 1.0, w.z + 0.5);
                if (sc != null) {
                    int px = (int) sc[0];
                    int py = (int) sc[1];
                    ctx.fill(px - 2, py - 2, px + 3, py + 3, col);
                    Draw.center(ctx, mc.textRenderer, label, px, py - 12, col);
                }
            }
        }
    }
}
