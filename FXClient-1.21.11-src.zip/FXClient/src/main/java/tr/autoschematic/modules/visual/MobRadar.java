package tr.autoschematic.modules.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import tr.autoschematic.Look;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;
import tr.autoschematic.gui.Theme;
import tr.autoschematic.modules.auto.SpawnerScan;

/** Köşede küçük bir radar: yakındaki moblar ve spawner'lar. Oyuncular gösterilmez. */
public final class MobRadar extends Feature {
    private final Setting.Num size = add(new Setting.Num("Radar yarıçapı (px)", 56, 30, 100, 2));
    private final Setting.Num range = add(new Setting.Num("Menzil (blok)", 48, 16, 128, 4));
    private final Setting.Mode corner = add(new Setting.Mode("Konum", "Sol alt", "Sağ alt", "Sol üst", "Sağ üst"));
    private final Setting.Bool hostile = add(new Setting.Bool("Düşman moblar", true));
    private final Setting.Bool passive = add(new Setting.Bool("Hayvanlar", false));
    private final Setting.Bool spawners = add(new Setting.Bool("Spawner'lar", true));

    public MobRadar() {
        super("Mob Radar", "Köşede küçük radar: yakındaki düşman moblar, hayvanlar ve spawner'lar. Oyuncuları göstermez.",
                Category.VISUALS);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (spawners.v) SpawnerScan.tick(mc, 12);
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc, float tickProgress) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null) return;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int rad = size.i();
        int margin = 10;
        int cx = (corner.idx == 0 || corner.idx == 2) ? margin + rad : sw - margin - rad;
        int cy = (corner.idx == 0 || corner.idx == 1) ? sh - margin - rad - 24 : margin + rad + 30;

        for (int dy = -rad; dy <= rad; dy += 1) {                       // dolu disk
            int half = (int) Math.sqrt((double) rad * rad - (double) dy * dy);
            ctx.fill(cx - half, cy + dy, cx + half, cy + dy + 1, 0x88101214);
        }
        int ring = Theme.accentA(0xB0);
        for (int a = 0; a < 360; a += 6) {                              // çember
            int x = cx + (int) Math.round(Math.cos(Math.toRadians(a)) * rad);
            int y = cy + (int) Math.round(Math.sin(Math.toRadians(a)) * rad);
            ctx.fill(x, y, x + 1, y + 1, ring);
        }
        ctx.fill(cx - rad, cy, cx + rad, cy + 1, 0x33FFFFFF);
        ctx.fill(cx, cy - rad, cx + 1, cy + rad, 0x33FFFFFF);

        double yaw = Math.toRadians(Look.active ? Look.yaw : p.getYaw(tickProgress));
        double fx = -Math.sin(yaw);
        double fz = Math.cos(yaw);
        double rx = -Math.cos(yaw);
        double rz = -Math.sin(yaw);
        double rg = range.v;

        for (Entity e : w.getEntities()) {
            if (!(e instanceof MobEntity m) || !m.isAlive()) continue;
            boolean isHostile = m instanceof Monster;
            if (isHostile ? !hostile.v : !passive.v) continue;
            double dx = m.getX() - p.getX();
            double dz = m.getZ() - p.getZ();
            double right = dx * rx + dz * rz;
            double fwd = dx * fx + dz * fz;
            if (Math.sqrt(right * right + fwd * fwd) > rg) continue;
            int px = cx + (int) (right / rg * rad);
            int py = cy - (int) (fwd / rg * rad);
            ctx.fill(px - 1, py - 1, px + 2, py + 2, isHostile ? 0xFFFF5555 : 0xFF55FF88);
        }
        if (spawners.v) {
            for (SpawnerScan.Spawner s : SpawnerScan.list) {
                double dx = s.pos.getX() + 0.5 - p.getX();
                double dz = s.pos.getZ() + 0.5 - p.getZ();
                double right = dx * rx + dz * rz;
                double fwd = dx * fx + dz * fz;
                if (Math.sqrt(right * right + fwd * fwd) > rg) continue;
                int px = cx + (int) (right / rg * rad);
                int py = cy - (int) (fwd / rg * rad);
                ctx.fill(px - 2, py - 2, px + 3, py + 3, 0xFFFF2D2D);
            }
        }
        ctx.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFFFFFFFF);          // sen
    }
}
