package tr.autoschematic.modules.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Features;
import tr.autoschematic.core.Setting;

/**
 * El sallama animasyonunu yavaşlatır (sadece görsel).
 * Kendi sallama zamanlayıcısını tutar ve oyuncunun "el sallama ilerlemesi" değerini
 * kareler arasında akıcı biçimde (LivingEntityMixin üzerinden) değiştirir.
 */
public final class SlowHand extends Feature {
    private final Setting.Num slow = add(new Setting.Num("Yavaşlık (kat)", 2.5, 1.5, 8.0, 0.5));
    private boolean anim;
    private float prev;
    private float cur;

    public SlowHand() {
        super("Slow Hand", "El sallama animasyonunu akıcı biçimde yavaşlatır. Vuruş/kazma hızını etkilemez.",
                Category.VISUALS);
    }

    @Override
    public void onDisable() {
        anim = false;
        prev = 0f;
        cur = 0f;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        prev = cur;
        if (anim) {
            cur += 1.0f / (6.0f * slow.f());      // vanilla sallama 6 tick sürer
            if (cur >= 1.0f) {
                anim = false;
                cur = 0f;
                prev = 0f;
            }
        }
        if (!anim && p.handSwinging) {            // yeni sallama başladı
            anim = true;
            cur = 0f;
            prev = 0f;
        }
    }

    /** LivingEntityMixin çağırır: yerel oyuncunun sallama ilerlemesi. null = dokunma. */
    public static Float modify(float original, float tickProgress) {
        SlowHand s = Features.SLOW_HAND;
        if (s == null || !s.enabled || !s.anim) return null;
        return s.prev + (s.cur - s.prev) * tickProgress;
    }
}
