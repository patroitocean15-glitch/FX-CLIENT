package tr.autoschematic.modules.visual;

import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;

/** Elindeki eşya elin biraz üstünde süzülür ve 360° döner. Çizimi VisualFx yapar. */
public final class BetterItem extends Feature {
    public final Setting.Bool spin = add(new Setting.Bool("Dönsün", true));
    public final Setting.Num speed = add(new Setting.Num("Dönme hızı (°/sn)", 180, 30, 720, 15));
    public final Setting.Num hover = add(new Setting.Num("Süzülme yüksekliği", 0.12, 0.0, 0.5, 0.01));
    public final Setting.Num size = add(new Setting.Num("Eşya boyutu", 1.0, 0.5, 1.5, 0.05));

    public BetterItem() {
        super("Better Item", "Elindeki eşya elin biraz üstünde durur ve sürekli 360° döner.", Category.VISUALS);
    }
}
