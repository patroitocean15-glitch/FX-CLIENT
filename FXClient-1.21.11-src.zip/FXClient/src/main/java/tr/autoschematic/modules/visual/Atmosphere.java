package tr.autoschematic.modules.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;

/** İstemci tarafı hava ve zaman: sadece sende görünür, sunucuyu değiştirmez. */
public final class Atmosphere extends Feature {
    private final Setting.Mode weather = add(new Setting.Mode("Hava", "Normal", "Açık", "Yağmur", "Fırtına"));
    private final Setting.Bool lockTime = add(new Setting.Bool("Zamanı sabitle", false));
    private final Setting.Num time = add(new Setting.Num("Zaman (tick)", 6000, 0, 24000, 250));

    public Atmosphere() {
        super("Atmosphere", "Hava durumunu ve günün saatini sadece senin ekranında değiştirir.", Category.VISUALS);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientWorld w = mc.world;
        if (w == null) return;
        switch (weather.idx) {
            case 1 -> {
                w.setRainGradient(0f);
                w.setThunderGradient(0f);
            }
            case 2 -> {
                w.setRainGradient(1f);
                w.setThunderGradient(0f);
            }
            case 3 -> {
                w.setRainGradient(1f);
                w.setThunderGradient(1f);
            }
            default -> {
                // Normal: sunucunun hava durumu
            }
        }
        if (lockTime.v) {
            w.getLevelProperties().setTimeOfDay((long) time.v);
        }
    }
}
